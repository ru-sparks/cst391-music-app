// Define the shape of props expected by the AlbumCard component.
// This interface acts as a contract, ensuring that any use of AlbumCard

import { Album } from "@/lib/types";
import Link from "next/link";

// must provide exactly these props with the correct types.
interface AlbumCardProps {
    // The `album` prop must be an object of type Album.
    // This type is likely defined elsewhere in your codebase and describes
    // the structure of an album (e.g., title, artist, cover image, etc.).
    album: Album;

    // The `onClick` prop is a function that takes two arguments:
    // - an Album object
    // - a string representing a URI (e.g., "/show" or "/edit")
    // and returns nothing (void).
    // This ensures that any click handler passed to AlbumCard
    // adheres to this exact signature, preventing runtime errors.
    onClick: (album: Album, uri: string) => void;
}

// Export a functional React component named AlbumCard.
// The props are destructured directly in the parameter list,
// and their shape is validated against the AlbumCardProps interface.
export default function AlbumCard({ album, onClick }: AlbumCardProps) {

    return (
        <div className='container'>
            <h2>Album Details for {album.title}</h2>
            <div className='row'>
                <div className='col col-sm-3'>
                    <div className='card'>
                        <img
                            src={album.image ?? ''}
                            className='card-img-top'
                            alt={album.title}
                        />
                        <div className='card-body'>
                            <h5 className='card-title'>{album.title}</h5>
                            <p className='card-text'>{album.description}</p>
                            <Link href="/" className="btn btn-primary">
                                Back
                            </Link>
                        </div>
                    </div>
                </div>
                <div className='col col-sm-9'>
                    <div className='card'>
                        <p>Show the lyrics of select track here</p>
                    </div>
                    <div className='card'>
                        <p>Show the YouTube Video of select track here</p>
                    </div>
                </div>
            </div>
        </div>
    );
};
